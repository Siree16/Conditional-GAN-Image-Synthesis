Porject Name:- Conditional Generative Adversarial Network (cGAN) for Image Synthesis with Class Labels
Course Computer Vision (CSL7360)
By:- Bhavesh Khatri (M23CSE011)
       Sireejaa Uppal (M23CSE023)
       Ritu Singh (M23CSE023)
       Ritobina Ghosh (M23CSA021)

Submitted To:- 
Dr. Rajendra Nagar
Assistant Professor
Department of Electrical Engineering
Indian Institute of Technology Jodhpur (IITJ)
